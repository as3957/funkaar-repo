<?php
/*
Template Name: Blog
*/
?>

<?php get_header(); ?>

 	<?php if (!option::is_on('sidebar_home') ) { echo "<div class=\"full-width\">"; } ?>

 		<div id="content">

 			<div class="section-title">

				<h2><?php the_title(); ?></h2>

			</div><!-- /.section-title -->

			<div class="archive-blog">

				<?php // WP 3.0 PAGED BUG FIX
				if ( get_query_var('paged') )
					$paged = get_query_var('paged');
				elseif ( get_query_var('page') )
					$paged = get_query_var('page');
				else
					$paged = 1;

				query_posts("paged=$paged"); if (have_posts()) :
				?>

					<ul class="recent-posts">

						<?php while ( have_posts() ) : the_post(); ?>

				 			<?php get_template_part( 'content', 'blog' ); ?>

			 			<?php endwhile; ?>

		 			</ul>

				<?php endif; ?>

			</div><!-- /.archive-blog -->

			<?php get_template_part( 'pagination'); ?>

		</div><!-- /#content -->

	<?php if (!option::is_on('sidebar_home') ) { echo "</div>";	} else {
		get_sidebar();
	} ?>

	<div class="clear"></div>

<?php get_footer(); ?>
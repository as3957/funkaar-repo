<?php get_header(); ?>

	<?php if (!option::is_on('sidebar_home') ) { echo "<div class=\"full-width\">"; } ?>

		<div id="content">

			<div class="section-title">
				<h2><?php _e('Search Results for','wpzoom');?> <strong>"<?php the_search_query(); ?>"</strong></h2>
			</div><!-- /.section-title -->

			<?php if (option::get('post_layout') == 'List') { ?><div class="archive-blog"><?php } ?>

		        <ul class="recent-posts">

					<?php while ( have_posts() ) : the_post(); ?>

			 			<?php get_template_part( 'content', get_post_format() ); ?>

		 			<?php endwhile; ?>

				</ul>

			<?php if (option::get('post_layout') == 'List') { ?></div><!-- /.archive-blog --><?php } ?>

			<?php get_template_part( 'pagination'); ?>

		</div><!-- /#content -->

	<?php if (!option::is_on('sidebar_home') ) { echo "</div>";	} else {
			get_sidebar();
		} ?>

	<div class="clear"></div>

<?php get_footer(); ?>
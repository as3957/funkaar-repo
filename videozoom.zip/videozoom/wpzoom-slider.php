<div id="featured-slider">
	<div id="slider" class="flexslider">
		<?php
		$postsno = option::get( 'slideshow_posts' );
		$featured_posts = new WP_Query( array(
			'post__not_in'   => get_option( 'sticky_posts' ),
			'posts_per_page' => $postsno,
			'meta_key'       => 'wpzoom_is_featured',
			'meta_value'     => 1
		) );
		?>

		<?php if ( $featured_posts->post_count == 0 ) : ?>

			<div class="slnotice">
				<p>There are no featured posts to be shown in the slider. Start marking posts as featured, or disable the slider from <strong><a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=wpzoom_options">Theme Options</a></strong>. <br /></p>
				<p>For more information please <strong><a href="http://www.wpzoom.com/documentation/videozoom/">read the documentation</a></strong>.</p>
			</div>

		<?php endif; ?>

		<?php if ( $featured_posts->post_count > 0 ) : ?>

			<ul class="slides">
				<?php
				while ( $featured_posts->have_posts() ) :
					$featured_posts->the_post();
					$videotype       = get_post_meta( get_the_ID(), 'wpzoom_video_type', true );
					$videoexternal   = get_post_meta( get_the_ID(), 'wpzoom_post_embed_code', true );
					$videoselfhosted = get_post_meta( get_the_ID(), 'wpzoom_post_embed_self', true );
				?>

					<li>
                        <?php if ( empty( $videoexternal ) && empty( $videoselfhosted ) ) : ?>

                            <?php /* No video? Display featured image. */ ?>
                            <?php get_the_image( array( 'size' => 'slider', 'width' => 560, 'height' => 315 ) ); ?>

                        <?php else: ?>

                            <?php
                            if ( $videotype == 'external' && ! empty( $videoexternal ) ) {
                                $video_embed = embed_fix( $videoexternal, 560, 315 );
                            }

                            if ( $videotype != 'external' && ! empty( $videoselfhosted ) ) {
                                $poster = get_the_image( array( 'size' => 'slider', 'width' => 560, 'height' => 315, 'echo' => false, 'format' => 'array' ) );

                                $poster_attr = '';
                                if ($poster) {
                                    $poster_attr = 'poster="' . $poster['src'] . '"';
                                }

                                $video_embed = do_shortcode('[video width="560" height="315" mp4="' . $videoselfhosted . '" ' . $poster_attr . ' preload="none"][/video]');
                            }
                            ?>

                            <div class="video-cover"></div><!-- /.cover -->
                            <div class="video-embed" data-embed="<?php echo esc_attr( $video_embed ); ?>"></div>

                        <?php endif; ?>

						<div class="post-content">

							<div class="post-meta">

								<?php if ( option::is_on( 'slider_date' ) ) { ?>
									<span><?php echo get_the_date(); ?></span>
								<?php }

								if ( option::is_on( 'slider_category' ) ) { ?>
									<span><?php the_category( ', ' ); ?></span>
								<?php } ?>

								<?php edit_post_link( __('Edit', 'wpzoom'), '<span>', '</span>'); ?>
							</div>

							<h2 class="entry-title">
								<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
									<?php the_title(); ?>
								</a>
							</h2>

							<?php the_excerpt(); ?>

							<?php if ( option::is_on('slider_morebtn') ) : ?>
								<a href="<?php the_permalink() ?>" class="more-link" title="<?php the_title(); ?>"><?php _e('Read More', 'wpzoom'); ?> &raquo;</a>
							<?php endif; ?>


						</div><!-- ./postcontent -->
						<div class="cleaner">&nbsp;</div>
					</li>

				<?php endwhile; ?>
			</ul><!-- /.slides -->

		<?php endif; ?>

	</div><!-- /#slider -->
	<div class="cleaner">&nbsp;</div>

	<!-- start featured slider navigation -->
	<?php
	if ( $featured_posts->post_count > 0 ) :
		$featured_posts->rewind_posts();
	?>

		<div id="carousel" class="flexslider">
			<ul class="slides">
			 	<?php while ( $featured_posts->have_posts() ) : $featured_posts->the_post(); ?>
					<li>
						<?php
						get_the_image( array(
							'size'         => 'slider-small',
							'width'        => 160,
							'height'       => 120,
							'link_to_post' => false,
							'before'       => '<a href="#" rel="nofollow">',
							'after'        => '</a>'
						) );
						?>
					</li>
				<?php endwhile; ?>
			</ul>
		</div><!-- /#carousel -->

	<?php endif; ?>
	<!-- end featured slider navigation -->

</div><!-- / #featured-slider -->
<?php wp_reset_query(); ?>
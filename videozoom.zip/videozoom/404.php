<?php get_header(); ?>

	<?php if (!option::is_on('sidebar_home') ) { echo "<div class=\"full-width\">"; } ?>

		<div id="content">

			<div class="post-entry">

				<h1 class="entry-title"><?php _e('Error 404 - Nothing Found', 'wpzoom'); ?></h1>

				<div class="entry">

					<h3><?php _e('The page you are looking for could not be found.', 'wpzoom');?> </h3>

				</div>

			</div><!-- /.post-entry -->

			<div class="clear"></div>

		</div><!-- /#content -->

    <?php if (!option::is_on('sidebar_home') ) { echo "</div>";	} else {
		get_sidebar();
	} ?>

	<div class="clear"></div>

<?php get_footer(); ?>
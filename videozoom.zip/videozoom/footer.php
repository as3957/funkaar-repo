	</div><!-- /.inner-wrap -->

	<div id="footer">

		<div class="inner-wrap">

			<div id="footer-widgets">

				<div class="column">
				  <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer: Column 1') ) : ?> <?php endif; ?>
				</div><!-- /1st column -->

				<div class="column">
				  <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer: Column 2') ) : ?> <?php endif; ?>
				</div><!-- /2nd column -->

				<div class="column">
				  <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer: Column 3') ) : ?> <?php endif; ?>
				</div><!-- /3rd column -->

				<div class="column last">
				  <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer: Column 4') ) : ?> <?php endif; ?>
				</div><!-- /4th column -->

				<div class="clear"></div>

			</div><!-- /#footer-widgets -->

		</div><!-- /.inner-wrap -->


		<div id="footer-notice">

			<div class="inner-wrap">
 				<p class="site-copyright">&copy; <?php echo date("Y",time()); ?> <?php bloginfo('name'); ?>. <?php _e('All Rights Reserved', 'wpzoom') ?>.</p>
 				<p class="wpzoom"><a href="http://www.wpzoom.com" target="_blank"><?php _e('WordPress Video Theme', 'wpzoom'); ?></a> <?php _e('by', 'wpzoom'); ?> <a href="http://www.wpzoom.com" target="_blank" title="WordPress Video Themes">WPZOOM</a></p>
 				<div class="clear"></div>

			</div><!-- /.inner-wrap -->

		</div><!-- /#footer-notice -->

	</div><!-- /#footer -->

</div><!-- /.main-wrap -->

<?php wp_footer(); ?>
</body>
</html>
<?php
/*-----------------------------------------------------------------------------------*/
/* Initializing Widgetized Areas (Sidebars)											 */
/*-----------------------------------------------------------------------------------*/


/*----------------------------------*/
/* Sidebar                          */
/*----------------------------------*/

register_sidebar(array(
	'name'=>'Sidebar',
	'id' => 'sidebar',
	'before_widget' => '<div class="widget %2$s" id="%1$s">',
	'after_widget' => '<div class="clear"></div></div>',
	'before_title' => '<h3 class="title">',
	'after_title' => '</h3>',
));

/*----------------------------------*/
/* Home page				        */
/*----------------------------------*/

register_sidebar(array(
	'name'=>'Homepage: Content Widgets',
	'id' => 'sidebar-2',
	'description' => 'Add here WPZOOM: Homepage Posts widgets',
	'before_widget' => '<div id="%1$s" class="widget %2$s">',
	'after_widget' => '<div class="clear"></div></div>',
	'before_title' => '<h2 class="section-title">',
	'after_title' => '</h2>',
));


register_sidebar(array(
    'name'=>'Header Social Icons',
    'id' => 'header',
    'description' => 'Install the free plugin Social Icons Widget by WPZOOM and add it here.',
    'before_widget' => '<div id="%1$s" class="widget %2$s">',
    'after_widget' => '<div class="clear"></div></div>',
    'before_title' => '<h3 class="title">',
    'after_title' => '</h3>',
));


/*----------------------------------*/
/* Footer widgetized areas     		*/
/*----------------------------------*/

register_sidebar(array(
	'name'=>'Footer: Column 1',
	'id' => 'sidebar-4',
	'before_widget' => '<div class="widget %2$s" id="%1$s">',
	'after_widget' => '<div class="clear"></div></div>',
	'before_title' => '<h3 class="title">',
	'after_title' => '</h3>',
));

register_sidebar(array(
	'name'=>'Footer: Column 2',
	'id' => 'sidebar-5',
	'before_widget' => '<div class="widget %2$s" id="%1$s">',
	'after_widget' => '<div class="clear"></div></div>',
	'before_title' => '<h3 class="title">',
	'after_title' => '</h3>',
));

register_sidebar(array(
	'name'=>'Footer: Column 3',
	'id' => 'sidebar-6',
	'before_widget' => '<div class="widget %2$s" id="%1$s">',
	'after_widget' => '<div class="clear"></div></div>',
	'before_title' => '<h3 class="title">',
	'after_title' => '</h3>',
));

register_sidebar(array(
	'name'=>'Footer: Column 4',
	'id' => 'sidebar-7',
	'before_widget' => '<div class="widget %2$s" id="%1$s">',
	'after_widget' => '<div class="clear"></div></div>',
	'before_title' => '<h3 class="title">',
	'after_title' => '</h3>',
));

?>
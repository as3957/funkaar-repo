<?php
/**
 * Theme functions and definitions
 *
 * Set up the theme and provides some helper functions, which are used in the
 * theme as custom template tags. Others are attached to action and filter
 * hooks in WordPress to change core functionality.
 *
 * When using a child theme you can override certain functions (those wrapped
 * in a function_exists() call) by defining them first in your child theme's
 * functions.php file. The child theme's functions.php file is included before
 * the parent theme's file, so the child theme functions would be used.
 */

if ( ! function_exists( 'videozoom_setup' ) ) :
/**
 * Theme setup.
 *
 * Set up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support post thumbnails.
 */
function videozoom_setup() {

    // This theme styles the visual editor to resemble the theme style.
    add_editor_style( array( 'css/editor-style.css' ) );

     /* Slider */
    add_image_size( 'slider', 560, 315, true );
    add_image_size( 'slider-small', 160, 120, true );

    add_image_size( 'loop', 260, 180, true );

    /*
     * Let WordPress manage the document title.
     * By adding theme support, we declare that this theme does not use a
     * hard-coded <title> tag in the document head, and expect WordPress to
     * provide it for us.
     */
    add_theme_support( 'title-tag' );

    /*
     * Switch default core markup for search form, comment form, and comments
     * to output valid HTML5.
     */
    add_theme_support( 'html5', array(
        'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
    ) );

    // Register nav menus
    register_nav_menus( array(
        'secondary' => __( 'Top Menu', 'wpzoom' ),
        'primary' => __( 'Main Menu', 'wpzoom' )
    ) );
}
endif;
add_action( 'after_setup_theme', 'videozoom_setup' );



/* Register Video Post Format
==================================== */

add_theme_support( 'post-formats', array( 'video' ) );




/* Video auto-thumbnail
==================================== */

if (is_admin()) {
    WPZOOM_Video_Thumb::init();
}



/* Jetpack's Infinite Scroll support
=========================================== */

function wpzoom_infinite_scroll_init() {
    add_theme_support( 'infinite-scroll', array(
        'container' => 'content',
        'wrapper' => '.recent-posts'
    ) );
}

add_action( 'after_setup_theme', 'wpzoom_infinite_scroll_init' );



/*  Add Support for Shortcodes in Excerpt
========================================== */

add_filter( 'the_excerpt', 'shortcode_unautop' );
add_filter( 'the_excerpt', 'do_shortcode' );

add_filter( 'widget_text', 'shortcode_unautop' );
add_filter( 'widget_text', 'do_shortcode' );



/* Add support for Custom Background
==================================== */

add_theme_support( 'custom-background' );


/* Custom Excerpt Length
==================================== */

function new_excerpt_length($length) {
    return (int) option::get("excerpt_length") ? (int) option::get("excerpt_length") : 50;
}
add_filter('excerpt_length', 'new_excerpt_length');



/* Reset [gallery] shortcode styles
==================================== */

add_filter('gallery_style', create_function('$a', 'return "<div class=\'gallery\'>";'));



/* Video Embed Code Fix
==================================== */

function embed_fix($videoexternal,$width,$height) {

    if ( stripos($videoexternal, '[jwplayer') !== false ) {

        if ( class_exists('JWP6_Shortcode') && method_exists('JWP6_Shortcode', 'widget_text_filter') ) {

            return JWP6_Shortcode::widget_text_filter($videoexternal);

        } elseif ( function_exists('jwplayer_tag_widget_callback') ) {

            return jwplayer_tag_widget_callback($videoexternal);
        }
    }

    $videoexternal = preg_replace("/(width\s*=\s*[\"\'])[0-9]+([\"\'])/i", "$1 ".$width." $2", $videoexternal);
    $videoexternal = preg_replace("/(height\s*=\s*[\"\'])[0-9]+([\"\'])/i", "$1 ".$height." $2", $videoexternal);
    if (strpos($videoexternal, "<embed src=" ) !== false) {
          $videoexternal = str_replace('</param><embed', '</param><param name="wmode" value="transparent"></param><embed wmode="transparent" ', $videoexternal);
    }
    else {
        if(strpos($videoexternal, "wmode=transparent") == false){

            $re1='.*?';    # Non-greedy match on filler
            $re2='((?:\\/{2}[\\w]+)(?:[\\/|\\.]?)(?:[^\\s"]*))';    # HTTP URL 1

            if ($c=preg_match_all ("/".$re1.$re2."/is", $videoexternal, $matches))
            {
                $httpurl1=$matches[1][0];
            }

            if(strpos($httpurl1, "?") == true){
                $httpurl_new = $httpurl1 . '&wmode=transparent';
            }
            else {
                $httpurl_new = $httpurl1 . '?wmode=transparent';
            }

            $search = array($httpurl1);
            $replace = array($httpurl_new);
            $videoexternal = str_replace($search, $replace, $videoexternal);

            //print($httpurl_new);
            unset($httpurl_new);

        }
    }
    return $videoexternal;
}


/* Maximum width for images in posts
=========================================== */

if ( ! isset( $content_width ) ) {
    $content_width = 830;
}




/* Comments Custom Template
==================================== */

function wpzoom_comment( $comment, $args, $depth ) {
    $GLOBALS['comment'] = $comment;
    switch ( $comment->comment_type ) :
        case '' :
            ?>
            <li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
            <div id="comment-<?php comment_ID(); ?>">
                <div class="comment-author vcard">
                    <?php echo get_avatar( $comment, 50 ); ?>
                    <?php printf( '<cite class="fn">%s</cite>', get_comment_author_link() ); ?>

                    <div class="comment-meta commentmetadata"><a
                            href="<?php echo esc_url( get_comment_link( $comment->comment_ID ) ); ?>">
                            <?php printf( __( '%s @ %s', 'wpzoom' ), get_comment_date(), get_comment_time() ); ?></a>
                            <?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'], 'reply_text' => __( 'Reply', 'wpzoom' ), 'before' => '&nbsp;·&nbsp;&nbsp;' ) ) ); ?>
                            <?php edit_comment_link( __( 'Edit', 'wpzoom' ), '&nbsp;·&nbsp;&nbsp;' ); ?>

                    </div>
                    <!-- .comment-meta .commentmetadata -->

                </div>
                <!-- .comment-author .vcard -->
                <?php if ( $comment->comment_approved == '0' ) : ?>
                    <em class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.', 'wpzoom' ); ?></em>
                    <br/>
                <?php endif; ?>

                <div class="comment-body"><?php comment_text(); ?></div>

            </div><!-- #comment-##  -->

            <?php
            break;
        case 'pingback'  :
        case 'trackback' :
            ?>
            <li class="post pingback">
            <p><?php _e( 'Pingback:', 'wpzoom' ); ?> <?php comment_author_link(); ?><?php edit_comment_link( __( '(Edit)', 'wpzoom' ), ' ' ); ?></p>
            <?php
            break;
    endswitch;
}



/* Allow to submit <iframe> embed code via Gravity Forms
==================================== */

add_filter( 'gform_allowable_tags', 'allow_basic_tags' );
function allow_basic_tags( $allowable_tags ) {
    return '<iframe></iframe>';
}



/* Enqueue scripts and styles for the front end.
=========================================== */

function videozoom_scripts() {

    $protocol = is_ssl() ? 'https' : 'http';

    /* Load our main stylesheet */
    wp_enqueue_style( 'videozoom-style', get_stylesheet_uri() );

    /* Media Queries stylesheet */
    wp_enqueue_style( 'media-queries', get_template_directory_uri() . '/css/media-queries.css', array(), WPZOOM::$themeVersion );

    wp_enqueue_style( 'dashicons' );

    wp_enqueue_script( 'fitvids', get_template_directory_uri() . '/js/fitvids.min.js', array( 'jquery' ), WPZOOM::$themeVersion, true );

    wp_enqueue_script( 'mmenu', get_template_directory_uri() . '/js/jquery.mmenu.min.all.js', array( 'jquery' ), WPZOOM::$themeVersion, true );

    wp_enqueue_script( 'superfish', get_template_directory_uri() . '/js/superfish.min.js', array( 'jquery' ), WPZOOM::$themeVersion, true );

    wp_enqueue_script( 'videozoom-script', get_template_directory_uri() . '/js/functions.js', array( 'jquery' ), WPZOOM::$themeVersion, true );


    if ( is_home() && option::is_on( 'featured_enable' ) ) {
        if ( option::is_on( 'featured_rotate' ) ) {
            wp_enqueue_script( 'frogaloop', '//secure-a.vimeocdn.com/js/froogaloop2.min.js' );
            wp_enqueue_script( 'youtube-player-api', '//www.youtube.com/player_api' );
        }

        wp_enqueue_script( 'flexslider', get_template_directory_uri() . '/js/flexslider.js', array( 'jquery' ), '20130110' );
        wp_enqueue_script( 'videozoom-slider', get_template_directory_uri() . '/js/slider.js', array( 'jquery', 'fitvids', 'flexslider' ), '20130110' );
        wp_localize_script( 'videozoom-slider', 'featuredSliderDefaults', json_encode( array(
            'slideshow'      => option::is_on( 'featured_rotate' ),
            'animation'      => ( option::get( 'slideshow_effect' ) == 'Slide' ) ? 'slide' : 'fade',
            'slideshowSpeed' => intval( option::get( 'featured_interval' ) ),
            'pauseOnHover'   => option::is_on( 'featured_pause_hover' )
        ) ) );
    }


    /* Google Fonts */
    wp_enqueue_style( 'google-fonts', "$protocol://fonts.googleapis.com/css?family=Ropa+Sans|Open+Sans:400,600,700" );
}
add_action( 'wp_enqueue_scripts', 'videozoom_scripts' );

<?php

/* Custom Post Layouts
==================================== */

function wpzoom_post_layout_options() {
	global $post;
	$postLayouts = array('side-right' => 'Sidebar on the right', 'full' => 'Full Width');
	?>

	<style>
	.RadioClass { display: none !important; }
	.RadioLabelClass { margin-right: 10px; }
	img.layout-select { border: solid 4px #c0cdd6; border-radius: 5px; }
	.RadioSelected img.layout-select { border: solid 4px #3173b2; }

	#wpzoom_post_embed_code { color: #444444; font-size: 11px; margin: 3px 0 10px; padding: 5px; font-family: Consolas,Monaco,Courier,monospace; }

	.wpz_video { background: url(images/media-button-video.gif) no-repeat; padding: 0 0 0 18px; }
	.wpz_list { font-size: 11px; }
	.wpz_self_input { border: 1px solid #DFDFDF; border-radius: 4px 4px 4px 4px; width: 230px; color: #444444; }
	.wpz_border { border-bottom: 1px solid #EEEEEE; padding: 0 0 10px; }

 	</style>

	<script type="text/javascript">
		jQuery(document).ready( function($) {
			$(".RadioClass").change(function(){
			    if($(this).is(":checked")){
			        $(".RadioSelected:not(:checked)").removeClass("RadioSelected");
			        $(this).next("label").addClass("RadioSelected");
			    }
			});
 		});
  	</script>

	<fieldset>
		<div>
 			<p>
 			<?php
			foreach ($postLayouts as $key => $value)
			{
				?>
				<input id="<?php echo $key; ?>" type="radio" class="RadioClass" name="wpzoom_post_template" value="<?php echo $key; ?>"<?php if (get_post_meta($post->ID, 'wpzoom_post_template', true) == $key) { echo' checked="checked"'; } ?> />
				<label for="<?php echo $key; ?>" class="RadioLabelClass<?php if (get_post_meta($post->ID, 'wpzoom_post_template', true) == $key) { echo' RadioSelected"'; } ?>">
				<img src="<?php echo wpzoom::$wpzoomPath; ?>/assets/images/layout-<?php echo $key; ?>.png" alt="<?php echo $value; ?>" title="<?php echo $value; ?>" class="layout-select" /></label>
			<?php
			}
			?>
 			</p>
   		</div>
	</fieldset>
	<?php
}


/* Custom Posts Options
==================================== */

add_action('admin_menu', 'wpzoom_options_box');

function wpzoom_options_box() {
	add_meta_box('wpzoom_post_layout', 'Post Layout', 'wpzoom_post_layout_options', 'post', 'normal', 'high');
	add_meta_box('wpzoom_post_embed', 'Post Options', 'wpzoom_post_embed_info', 'post', 'side', 'high');
}


function wpzoom_post_embed_info() {
	global $post;

	/* Keys should never change for backwards compatibility! */
	$locations = array(
		'In the middle column'   => __( 'In the middle column', 'wpzoom' ),
		'Before everything else' => __( 'Before everything else', 'wpzoom' ),
		'Hide video in post'     => __( 'Hide video in post', 'wpzoom' )
	);
	$selected_location = get_post_meta($post->ID, 'wpzoom_post_embed_location', true);

	?>
	<fieldset>
		<div>

			<p class="wpz_border">
 				<?php $isChecked = ( get_post_meta($post->ID, 'wpzoom_is_featured', true) == 1 ? 'checked="checked"' : '' ); // we store checked checkboxes as 1 ?>
				<input type="checkbox" name="wpzoom_is_featured" id="wpzoom_is_featured" value="1" <?php echo $isChecked; ?> /> <label for="wpzoom_is_featured"><?php _e( 'Feature on Homepage', 'wpzoom' ); ?></label>
			</p>

			<p class="wpz_border">
				<label for="wpzoom_post_embed_location" ><strong><?php _e('Video location in the post', 'wpzoom' ); ?>:</strong></label><br />
				<select name="wpzoom_post_embed_location" id="wpzoom_post_embed_location">

				<?php foreach ( $locations as $value => $text ) : ?>
					<option <?php selected( $selected_location, $value ); ?> value="<?php echo esc_attr( $value ); ?>">
						<?php echo esc_html( $text ); ?>
					</option>
				<?php endforeach; ?>

				</select>
				<br />
			</p>

			<p class="wpz_border" style="border-bottom:none; padding:0;">
				<strong><?php _e('Embed Video', 'wpzoom' ); ?>:</strong><br />

				<?php $videoType = get_post_meta($post->ID, 'wpzoom_video_type', true); ?>

				<label for="video_external">
					<input name="wpzoom_video_type" id="video_external" <?php if ($videoType == 'external' || !$videoType) { ?>checked="checked" <?php } ?>value="external" type="radio" onclick="document.getElementById('layout_select2').style.display = 'none'; document.getElementById('layout_select1').style.display = 'block'; " /> <?php _e('External Video', 'wpzoom' ); ?>
				</label>
				<label for="video_selfhosted">
					<input name="wpzoom_video_type" id="video_selfhosted" <?php if ($videoType == 'selfhosted') { ?>checked="checked" <?php } ?>value="selfhosted" type="radio" onclick="document.getElementById('layout_select1').style.display = 'none'; document.getElementById('layout_select2').style.display = 'block'; " /> <?php _e('Self-hosted Video', 'wpzoom' ); ?>
				</label>

				<div id="layout_select1" class="external"<?php if ($videoType == 'selfhosted') { ?> style="display:none"<?php } ?>>
					<p>
						<label for="wpzoom_post_embed_code" ><?php _e('Insert Embed Code (<em>YouTube, Vimeo, JW Player etc.</em>)', 'wpzoom' ); ?>:</label><br />
						<textarea style="height: 110px; width: 255px;" name="wpzoom_post_embed_code" id="wpzoom_post_embed_code"><?php echo get_post_meta($post->ID, 'wpzoom_post_embed_code', true); ?></textarea>
					</p>
				</div>

				<div id="layout_select2" class="selfhosted"<?php if ($videoType == 'external' || !$videoType) { ?> style="display:none"<?php } ?>>
				    <div class="wpz_border">
					<p>
 					<ol class="wpz_list ">
 						<?php if ( ui::is_wp_version( '3.6' ) ) { ?>
							<script type="text/javascript">
								jQuery(function($){
									var wpMediaFramePost = wp.media.view.MediaFrame.Post;
									wp.media.view.MediaFrame.Post = wpMediaFramePost.extend({
										mainInsertToolbar: function(view){
											wpMediaFramePost.prototype.mainInsertToolbar.call(this, view);
											var controller = this;
											this.selectionStatusToolbar(view);
											view.set('setSelfHosted', {
												style: 'primary',
												text: '<?php _e( 'Set self-hosted video', 'wpzoom' ); ?>',
												requires: { selection: true },
												click: function(){
													var state = controller.state(),
													    sel = state.get('selection').first().toJSON();
													if(sel.type == 'video') {
														$('#layout_select1').hide();
														$('#layout_select2').show();
														$('input#video_selfhosted').prop('checked', true);
														$('input#wpzoom_post_embed_self').val(sel.url).focus();
													}
													controller.close();
													state.reset();
												}
											});
										}
									});

									var media_frame = wp.media({
										title: '<?php _e( 'Select Video', 'wpzoom' ); ?>',
										multiple: false,
										library: { type: 'video' },
										button: { text: '<?php _e( 'Use This Video', 'wpzoom' ); ?>' }
									});
									media_frame.on('select', function(){
										$('input#wpzoom_post_embed_self').val(media_frame.state().get('selection').first().toJSON().url).focus();
									});

									$('a#wpz_upload_video').on('click', function(e){
										e.preventDefault();
										media_frame.open();
									});
								});
							</script>
							<li><a href="" id="wpz_upload_video" class="wpz_video">Upload video</a> to your website</li>
						<?php } else { ?>
							<li><a class="thickbox wpz_video" href="media-upload.php?post_id=9&type=video&TB_iframe=1">Upload video</a> to your website</li>
						<?php } ?>
	 					<li><?php _e('Insert video URL here', 'wpzoom' ); ?>:<br/>

							<input class="form-input-tip wpz_self_input" name="wpzoom_post_embed_self" id="wpzoom_post_embed_self" value="<?php echo get_post_meta($post->ID, 'wpzoom_post_embed_self', true); ?>" />
						</li>


					</ol>
					</p>
 				</div>
			</p>

			<p>
				<em><strong>Tips:</strong></em><br/>
				<ol class="wpz_list">
 					<li>Recommended video formats: <em>.flv, .mp4</em>. Read more about <a href="http://www.longtailvideo.com/support/jw-player/jw-player-for-flash-v5/12539/supported-video-and-audio-formats" target="_blank">supported formats</a>.</li>
 					<li><strong>HTML5</strong> videos (supported by iPhone/iPad) should be in <em>MP4</em> format, with <em>H.264</em> enconding. You can convert your videos with <a href="http://handbrake.fr/downloads.php" target="_blank">HandBrake</a> video converter.</li>

				</ol>
			</p>
			</div>
 		</div>
	</fieldset>
	<?php
}

add_action('save_post', 'custom_add_save');

function custom_add_save($postID){

	// called after a post or page is saved
	if($parent_id = wp_is_post_revision($postID))
	{
	  $postID = $parent_id;
	}

	if (isset($_POST['save']) || isset($_POST['publish']) || (isset($_POST['wp-preview']) && $_POST['wp-preview'] == 'dopreview')) {

		update_custom_meta( $postID, ( isset( $_POST['wpzoom_is_featured'] ) ? 1 : 0 ), 'wpzoom_is_featured' );

		if (isset($_POST['wpzoom_post_template']))
			update_custom_meta($postID, $_POST['wpzoom_post_template'], 'wpzoom_post_template');

 		if (isset($_POST['wpzoom_post_embed_location']))
 			update_custom_meta($postID, $_POST['wpzoom_post_embed_location'], 'wpzoom_post_embed_location');

		if (isset($_POST['wpzoom_video_type']))
 			update_custom_meta($postID, $_POST['wpzoom_video_type'], 'wpzoom_video_type');

		if (isset($_POST['wpzoom_post_embed_code']))
 			update_custom_meta($postID, $_POST['wpzoom_post_embed_code'], 'wpzoom_post_embed_code');

		if (isset($_POST['wpzoom_post_embed_self']))
 			update_custom_meta($postID, $_POST['wpzoom_post_embed_self'], 'wpzoom_post_embed_self');

	}
}

function update_custom_meta($postID, $newvalue, $field_name) {
	// To create new meta
	if(!get_post_meta($postID, $field_name)){
	add_post_meta($postID, $field_name, $newvalue);
	}else{
	// or to update existing meta
	update_post_meta($postID, $field_name, $newvalue);
	}
}


if (function_exists('jwplayer_init')) {

	add_filter("attachment_fields_to_edit", "videozoom_jwplayer_attachment_fields", 11, 2);
}



if ( class_exists('JWP6_Plugin') ) {
	add_filter("attachment_fields_to_edit", "videozoom_jwplayer6_attachment_fields", 100, 2);

	function videozoom_jwplayer6_attachment_fields($form_fields, $post) {
		// don't do anything if jwplayer for wp didn't modified form fields
		if ( !defined('JWP6') || !$form_fields[ JWP6 . 'insert_with_player' ] ) return $form_fields;

		$form_fields['jwplayer_featured'] = array(
			'input' => 'html',
			'html' => '<input type="submit" id="jwplayer-as-featured" class="button-primary" name="send[' . $post->ID . ']" value="' . esc_attr__( 'Use JW Player as Featured', 'wpzoom' ) . '" />
			<script type="text/javascript">
				jQuery(document).on("click", "#jwplayer-as-featured", function(e){
					e.preventDefault();
					var selected_player = jQuery("#jwp6_insert_with_player").val();
					wp.media.post("send-attachment-to-editor", {
						nonce: wp.media.view.settings.nonce.sendToEditor,
						attachment: {
							"id": ' . $post->ID . ',
							"player_name": selected_player,
							"' . JWP6 . 'insert_jwplayer": true,
							"' . JWP6 . 'mediaid": ' . $post->ID . '
						},
						html: "",
						post_id: wp.media.view.settings.post.id
					}).done(function(response){
						var $embedfield = jQuery("#wpzoom_post_embed_code");
						$embedfield.val(response);
						try{tb_remove();}catch(e){};
						$embedfield.focus();
					});
				});
			</script>'
		);

		return $form_fields;
	}
}

<li id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php if ( option::is_on( 'display_thumb' ) ) { ?>

		<div class="post-thumb">

			<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">

				<?php if ( has_post_format( 'video' ) ) {
					echo '<span class="video-icon"></span>';
					}
				?>

				<?php get_the_image( array( 'size' => 'loop', 'link_to_post' => false, 'width' => 260, 'height' => 180 ) );  ?>

			</a>

		</div>

	<?php } ?>

	<div class="post-content">

		<div class="post-meta">

			<?php if ( option::is_on( 'display_category' ) ) { ?>
				<span class="meta-category"><?php the_category(' / '); ?></span>
			<?php } ?>

			</div>

		<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>

		<div class="post-meta">

			<?php if ( option::is_on( 'display_date' ) ) { ?>
				<span class="meta-date"><?php echo get_the_date(); ?></span>
			<?php } ?>

				<?php edit_post_link( __('Edit', 'wpzoom'), '<span>', '</span>'); ?>

		</div>

		<?php the_excerpt(); ?>

		<?php if ( option::is_on( 'display_readmore' ) ) { ?>
			<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" class="more-link" rel="nofollow"><?php _e('Read more', 'wpzoom'); ?> &raquo;</a>
		<?php } ?>


	</div><div class="clear"></div>
</li>
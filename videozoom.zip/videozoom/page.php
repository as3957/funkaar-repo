<?php get_header(); ?>

 	<div id="content">

		<?php while (have_posts()) : the_post(); ?>

			<div class="post-entry">

				<h1 class="entry-title"><?php the_title(); ?></h1>

				<?php edit_post_link( __('Edit', 'wpzoom'), '', ''); ?>

				<div class="entry-content">
					<?php the_content(); ?>
				</div>

				<?php wp_link_pages(array('before' => '<strong>Pages:</strong> ', 'after' => '', 'next_or_number' => 'number')); ?>

			</div><!-- /.post-entry -->

			<div class="clear"></div>

			<?php if (option::get('comments_page') == 'on') {
				comments_template();
			} ?>

			<?php endwhile; ?>

		</div><!-- /#content -->

    <?php get_sidebar(); ?>

	<div class="clear"></div>

<?php get_footer(); ?>
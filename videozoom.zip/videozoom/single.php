<?php get_header(); ?>

<?php
	// Custom Post Options
	$template 		 = get_post_meta($post->ID, 'wpzoom_post_template', true);
	$videolocation 	 = get_post_meta($post->ID, 'wpzoom_post_embed_location', true);
	$videotype 		 = get_post_meta($post->ID, 'wpzoom_video_type', true);
	$videoexternal 	 = get_post_meta($post->ID, 'wpzoom_post_embed_code', true);
	$videoselfhosted = get_post_meta($post->ID, 'wpzoom_post_embed_self', true);
?>

<div id="main"<?php
	if ( $template == 'full' ) { echo ' class="full-width"'; }
	?>>

	<?php while (have_posts()) : the_post(); ?>

 		<?php if ($videolocation == 'Before everything else') {

 			if ($videotype == 'external') {

				if (strlen($videoexternal) > 1) { // Embedding video from external site
					$videoexternal = embed_fix($videoexternal,1170,658); // add wmode=transparent to iframe/embed
					?>
					<div class="zoomvideo_big"><?php echo "$videoexternal"; ?></div>
					<?php
				}
			} else {
				if (strlen($videoselfhosted) > 1 && $videotype == 'selfhosted') { // Embed self-hosted
					$poster = get_the_image( array( 'size' => 'slider', 'width' => 560, 'height' => 315, 'echo' => false, 'format' => 'array' ) );

					$poster_attr = '';
					if ($poster) {
					    $poster_attr = 'poster="' . $poster['src'] . '"';
					}
   				?>

					<div class="zoomvideo_big">

						<?php echo do_shortcode('[video width="1170" height="658" mp4="'.$videoselfhosted.'" ' . $poster_attr . '][/video]'); ?>

					</div>

				<?php }
			}

        }  ?>

        <div id="content">

			<div id="post-<?php the_ID(); ?>" <?php post_class('post-entry'); ?>>

				<?php if ($videolocation == 'In the middle column' && $template != 'full') {
 					if ($videotype == 'external') {
 						if (strlen($videoexternal) > 1) { // Embedding video from external site

						$videoexternal = embed_fix($videoexternal,830,467); // add wmode=transparent to iframe/embed
						echo "<div class=\"zoomvideo\">$videoexternal</div>"; }
					}

					if (strlen($videoselfhosted) > 1) { ?>

						<?php
						$poster = get_the_image( array( 'size' => 'slider', 'width' => 560, 'height' => 315, 'echo' => false, 'format' => 'array' ) );

						$poster_attr = '';
						if ($poster) {
						    $poster_attr = 'poster="' . $poster['src'] . '"';
						}
						?>

							<div class="zoomvideo">

								<?php echo do_shortcode('[video width="830" height="467" mp4="'.$videoselfhosted.'" ' . $poster_attr . '][/video]'); ?>

							</div>

					<?php }

	            } ?>

					<?php if ($videolocation == 'In the middle column' && $template == 'full') {
	 					if ($videotype == 'external') {
	 						if (strlen($videoexternal) > 1) { // Embedding video from external site
							$videoexternal = embed_fix($videoexternal,1170,658); // add wmode=transparent to iframe/embed
							echo "<div class=\"zoomvideo\">$videoexternal</div>"; }
						}
					else {
					  	if (strlen($videoselfhosted) > 1) { ?>

					  	<div class="zoomvideo">

 							<?php echo do_shortcode('[video width="1170" height="658" mp4="'.$videoselfhosted.'"][/video]'); ?>

						</div>

						<?php }
					}

	            } ?>

	          	<div class="post-meta">

	          		<?php if (option::get('post_author') == 'on') { ?><?php _e('Posted by', 'wpzoom') ?> <?php the_author_posts_link(); } ?>

	          		<?php if ( option::get('post_date') == 'on') { ?> <?php _e('on', 'wpzoom') ?> <?php echo get_the_date(); } ?>

					<?php if (option::get('post_category') == 'on') {  // Show Category? ?><?php _e('in', 'wpzoom') ?> <?php the_category(', '); ?><?php } ?>

          		</div>

	         	<h1 class="entry-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1>

	         	<?php edit_post_link( __('Edit', 'wpzoom'), ' ', ''); ?>

	         	<div class="entry-content">
	 				<?php the_content(); ?>
				</div>

	         	<?php wp_link_pages(array('before' => '<p class="pages"><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>


				<?php if (option::get('post_tags') == 'on') { // Show Tags??>
					<?php the_tags( '<div class="section tags">'.__('Tags', 'wpzoom').': ', ', ', '<div class="cleaner">&nbsp;</div></div>'); ?>
					<?php } ?>

				<?php if (option::get('post_share') == 'on') { // Show Social Icons? ?>
					<div class="meta-share">

						<h3><?php _e('Share', 'wpzoom') ?></h3>

					  	<ul>
					  		<li><a href="https://plus.google.com/share?url=<?php echo urlencode( get_permalink() ); ?>" target="_blank" title="<?php esc_attr_e( 'Post this to Google+', 'wpzoom' ); ?>" class="gplus"><?php echo option::get( 'post_share_label_gplus' ); ?></a></li>

							<li><a href="https://twitter.com/intent/tweet?url=<?php echo urlencode( get_permalink() ); ?>&text=<?php echo urlencode( get_the_title() ); ?>" target="_blank" title="<?php esc_attr_e( 'Tweet this on Twitter', 'wpzoom' ); ?>" class="twitter"><?php echo option::get( 'post_share_label_twitter' ); ?></a></li>

				            <li><a href="https://facebook.com/sharer.php?u=<?php echo urlencode( get_permalink() ); ?>&t=<?php echo urlencode( get_the_title() ); ?>" target="_blank" title="<?php esc_attr_e( 'Share this on Facebook', 'wpzoom' ); ?>" class="facebook"><?php echo option::get( 'post_share_label_facebook' ); ?></a></li>


	 				 	</ul>
						<div class="clear"></div>
					</div>
				<?php } // if social icons should be shown ?>


				<?php if (option::get('post_authorbio') == 'on') { ?>
					<div class="post_author">
						<?php echo get_avatar( get_the_author_meta('ID') , 70 ); ?>

						<span><?php _e('Author:', 'wpzoom'); ?> <?php the_author_posts_link(); ?></span>

						<p><?php the_author_meta('description'); ?></p>

						<div class="clear"></div>

						<span class="author_links">
							<ul>
								<li><?php _e('View', 'wpzoom'); ?>:</li>

								<?php if ( get_the_author_meta( 'user_url' ) ) { ?><li><a href="<?php echo the_author_meta('user_url'); ?>"><?php _e('My website', 'wpzoom'); ?></a></li><?php } ?>

								<li><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"><?php _e('All Posts', 'wpzoom'); ?></a></li>
							</ul>
						</span>
					</div>
				<?php } ?>

       			<div class="clear"></div>

       		</div><!-- /.single-post -->


	        <?php if (option::get('post_comments') == 'on') {
		        comments_template();
		        } ?>

      	</div><!-- /#content -->

     	<?php if ($template != 'full') { get_sidebar(); } ?>
  		<div class="clear"></div>

	<?php endwhile; ?>

</div><!-- /#main -->

<?php get_footer(); ?>
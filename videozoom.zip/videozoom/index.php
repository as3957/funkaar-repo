<?php get_header(); ?>

	<?php if (option::is_on('featured_enable') && is_home() && $paged < 2) { get_template_part('wpzoom', 'slider'); } // Show the Featured Slider? ?>


	<?php if (!option::is_on('sidebar_home') ) { echo "<div class=\"full-width\">"; } ?>

		<div id="content">

			<?php if ($paged < 2) {

				dynamic_sidebar('Homepage: Content Widgets');

			} ?>


			<?php if (option::get('recent_posts') == 'on') { // Display Recent Posts ?>

				<?php
					global $query_string; // required

					/* Exclude categories from Recent Posts */
					if (option::get('recent_part_exclude') != 'off') {
						if (count(option::get('recent_part_exclude'))){
							$exclude_cats = implode( ',-', (array) option::get('recent_part_exclude') );
								$exclude_cats = '-' . $exclude_cats;
							$args['cat'] = $exclude_cats;
						}
					}

					/* Exclude featured posts from Recent Posts */
					if (option::get('hide_featured') == 'on') {

						$featured_posts = new WP_Query(
							array(
								'post__not_in' => get_option( 'sticky_posts' ),
								'posts_per_page' => option::get('slideshow_posts'),
								'meta_key' => 'wpzoom_is_featured',
								'meta_value' => 1
								) );

						$postIDs = array();
						while ($featured_posts->have_posts()) {
							$featured_posts->the_post();
							global $post;
							$postIDs[] = $post->ID;
						}
						$args['post__not_in'] = $postIDs;
					}

					$args['paged'] = $paged;
					if (count($args) >= 1) {
						query_posts($args);
					}
					?>


					<div class="section-title">

						<h2><?php echo option::get('recent_title'); ?></h2>

					</div><!-- /.section-title -->

					<?php if (option::get('post_layout') == 'List') { ?><div class="archive-blog"><?php } ?>

						<ul class="recent-posts">

							<?php while ( have_posts() ) : the_post(); ?>

					 			<?php get_template_part( 'content', get_post_format() ); ?>

				 			<?php endwhile; ?>

			 			</ul>

		 			<?php if (option::get('post_layout') == 'List') { ?></div><!-- /.archive-blog --><?php } ?>

					<?php get_template_part( 'pagination'); ?>

					<?php wp_reset_query(); ?>

				<?php } // Display Recent Posts ?>

		</div><!-- /#content -->

	<?php if (!option::is_on('sidebar_home') ) { echo "</div><!--/.full-width -->";	} else {
		get_sidebar();
	} ?>

	<div class="clear"></div>

<?php get_footer(); ?>
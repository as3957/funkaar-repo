<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head>
    <meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
   	<meta name="viewport" content="width=device-width, initial-scale=1.0" />

	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<div class="main-wrap">

    <header class="site-header">

    	<nav class="top-navbar" role="navigation">
    	    <div class="inner-wrap">

        		<?php if ( is_active_sidebar( 'header' ) ) { ?>
        			<div id="social-nav">

        				<?php dynamic_sidebar('Header Social Icons'); ?>

         			</div>
        		<?php } ?>


    	        <div class="navbar-header">

                    <?php if (has_nav_menu( 'secondary' )) { ?>
        	            <a class="navbar-toggle" href="#menu-top-slide">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </a>

                        <?php wp_nav_menu( array(
                            'container_id'   => 'menu-top-slide',
                            'theme_location' => 'secondary'
                        ) );
                    } ?>

    	        </div>

    	        <div id="navbar-top">

    	            <?php if (has_nav_menu( 'secondary' )) {
                        wp_nav_menu( array(
    	                    'menu_class'     => 'nav navbar-nav dropdown sf-menu',
    	                    'theme_location' => 'secondary'
    	                ) );
    	            } else {
                        wp_nav_menu( array(
                           'menu_class'     => 'nav navbar-nav dropdown sf-menu',
                           'menu' => 'top'
                        ) );
                    } ?>

    	        </div><!-- #navbar-top -->
    	    </div>
    	</nav><!-- .navbar -->


    	<div class="inner-wrap">


    		<div class="navbar-brand">
    		    <?php if ( ! option::get( 'misc_logo_path' ) ) echo '<h1>'; ?>

    		    <a href="<?php echo home_url(); ?>" title="<?php bloginfo( 'description' ); ?>">
    		        <?php if ( ! option::get( 'misc_logo_path' ) ) { bloginfo( 'name' ); } else { ?>
    		            <img src="<?php echo ui::logo(); ?>" alt="<?php bloginfo( 'name' ); ?>" />
    		        <?php } ?>
    		    </a>

    		    <?php if ( ! option::get( 'misc_logo_path' ) ) echo '</h1>'; ?>
    		</div><!-- .navbar-brand -->



    		<?php if (option::get('ad_head_select') == 'on') { ?>
    			<div id="bannerHead">

    				<?php if ( option::get('ad_head_code') <> "") {
    					echo stripslashes(option::get('ad_head_code'));
    				} else { ?>
    					<a href="<?php echo option::get('banner_top_url'); ?>"><img src="<?php echo option::get('banner_top'); ?>" alt="<?php echo option::get('banner_top_alt'); ?>" /></a>
    				<?php } ?>

    			</div><!-- /#topad -->
    		<?php } ?>

    		<div class="clear"></div>


    	</div>


    	<nav class="main-navbar" role="navigation">
            <div class="inner-wrap">

    	        <div class="navbar-search">
    	           <?php get_search_form(); ?>
    	        </div>

                <div class="navbar-header">

                  <?php if (has_nav_menu( 'primary' )) { ?>

                        <a class="navbar-toggle" href="#menu-main-slide">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </a>


                        <?php wp_nav_menu( array(
                            'container_id'   => 'menu-main-slide',
                            'theme_location' => 'primary'
                        ) );
                    }  ?>

                </div>

                <div id="navbar-main">

                    <?php if (has_nav_menu( 'primary' )) {
                        wp_nav_menu( array(
                            'menu_class'     => 'nav navbar-nav dropdown sf-menu',
                            'theme_location' => 'primary'
                        ) );
                    } else {
                        wp_nav_menu( array(
                           'menu_class'     => 'nav navbar-nav dropdown sf-menu',
                           'menu' => 'main'
                        ) );
                    } ?>

                </div><!-- #navbar-main -->

                <div class="clear"></div>

            </div>

        </nav><!-- .navbar -->

    </header><!-- .site-header -->

    <div class="inner-wrap">
